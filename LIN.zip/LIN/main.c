#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

void getParityBits(uint8_t frameID, uint8_t P0, uint8_t P1){
    P0 = ((frameID&1)^((frameID>>1)&1)^((frameID>>2)&1)^((frameID>>4)&1));
    P1 = !(((frameID>>1)&1)^((frameID>>3)&1)^((frameID>>4)&1)^((frameID>>5)&1));
}

uint8_t getChecksum(uint8_t*ptr,uint8_t frameSize){
    uint8_t checksum = 0x00;
    uint16_t overflowChecksum = 0x00;
    for(uint8_t i = 0; i<frameSize; i++){
        if(overflowChecksum+*(ptr + i)>255){
            overflowChecksum=overflowChecksum+*(ptr + i)-255;
        }else overflowChecksum+=*(ptr + i);
    }
    checksum=overflowChecksum;
    return ~checksum;
}

int main()
{
    uint8_t frame[6]={0x10,0x55,0xAA,0xFA,0xFF,0xFF};
    uint8_t P0=0x00, P1=0x00;
    getParityBits(,P1,P0); //missing argument
    printf("%d",getChecksum(frame,sizeof(frame)/sizeof(uint8_t)));
    return 0;
}
