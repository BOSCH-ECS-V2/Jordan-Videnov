#include <stdio.h>
#include <stdlib.h>

void initializeMatrix(unsigned char ROWS, unsigned char COLS, unsigned char *ptr);
void mirror();
void printMatrix(unsigned char ROWS, unsigned char COLS, unsigned char *ptr);
void mirrorByDiagonal(unsigned char ROWS, unsigned char COLS, unsigned char *ptr);
void mirrorByRow(unsigned char ROWS, unsigned char COLS, unsigned char *ptr);
void mirrorByColumn(unsigned char ROWS, unsigned char COLS, unsigned char *ptr);

int main(){
    srand ( time(NULL) );
    mirror();
    return 0;
}

void mirror(){
    int ROWS, COLS,userInput;
    printf("Enter ROWS\n");
    scanf("%d", &ROWS);
    printf("Enter COLS\n");
    scanf("%d", &COLS);
    unsigned char matrix[ROWS*COLS];
    initializeMatrix(ROWS, COLS, matrix);

    if(ROWS==COLS){
        printf("Mirrored by main diagonal \n");
        mirrorByDiagonal(ROWS, COLS, matrix);
    }

    if(ROWS%2!=0){
        printf("Mirrored by centre row \n");
        mirrorByRow(ROWS, COLS, matrix);
    }else{
        printf("Mirrored by row \n");
        mirrorByRow(ROWS, COLS, matrix);
    }

    if(COLS%2!=0){
        printf("Mirrored by centre col \n");
        mirrorByColumn(ROWS, COLS, matrix);
    }else{
        printf("Mirrored by col \n");
        mirrorByColumn(ROWS, COLS, matrix);
    }

}

void initializeMatrix(unsigned char ROWS, unsigned char COLS, unsigned char *ptr){//utility function to initialize matrix
    for (int i = 0; i < ROWS*COLS; i++)
        *(ptr + i)=rand() % 255;
    printMatrix(ROWS, COLS, ptr);
}

void printMatrix(unsigned char ROWS, unsigned char COLS, unsigned char *ptr){//utility function to print matrix
    for (int i = 0; i < ROWS; i++){
        for (int j = 0; j < COLS; j++)
             printf("%d     ", *(ptr + i*COLS + j));
        printf("\n");
    }
    printf("\n");
}

void mirrorByDiagonal(unsigned char ROWS, unsigned char COLS, unsigned char *ptr){
    for (int i = 0; i < ROWS; i++){
        for (int j = i+1; j < COLS; j++){
             *(ptr + i*COLS + j) += *(ptr + j*COLS + i);
             *(ptr + j*COLS + i) = *(ptr + i*COLS + j) - *(ptr + j*COLS + i);
             *(ptr + i*COLS + j) -= *(ptr + j*COLS + i);
        }
    }
    printMatrix(ROWS, COLS, ptr);
}

void mirrorByRow(unsigned char ROWS, unsigned char COLS, unsigned char *ptr){
    int control = 1;
    for (int i = 0; i <= (ROWS/2)-1; i++){
            for (int j = 0; j < COLS; j++){
                *(ptr + i*COLS + j) += *(ptr + (i+(ROWS-control))*COLS + j);
                *(ptr + (i+(ROWS-control))*COLS + j) = *(ptr + i*COLS + j) - *(ptr + (i+(ROWS-control))*COLS + j);
                *(ptr + i*COLS + j) -= *(ptr + (i+(ROWS-control))*COLS + j);
            }
            control+=2;
    }
    printMatrix(ROWS, COLS, ptr);
}

void mirrorByColumn(unsigned char ROWS, unsigned char COLS, unsigned char *ptr){
    int control = 1;
    for (int i = 0; i < ROWS; i++){
            for (int j = 0; j <= (COLS/2)-1; j++){
                *(ptr + i*COLS + j) += *(ptr + i*COLS + j+(COLS-control));
                *(ptr + i*COLS + j+(COLS-control)) = *(ptr + i*COLS + j) - *(ptr + i*COLS + j+(COLS-control));
                *(ptr + i*COLS + j) -=*(ptr + i*COLS + j+(COLS-control));
            }
            control+=2;
    }
    printMatrix(ROWS, COLS, ptr);
}
